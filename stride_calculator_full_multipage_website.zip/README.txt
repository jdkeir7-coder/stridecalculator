STRIDE CALCULATOR — MULTI-PAGE WEBSITE

Upload these files to the ROOT of your GitHub Pages repository, preserving the folders.
Do NOT upload the ZIP itself; extract it first.

SITE PAGES
index.html                         Pace Conversion Tool (homepage)
calculator.html                    Split Calculator (formerly embedded in homepage)
about-faq.html                     About & FAQ
guides/index.html                  Pacing Guides library
guides/800m-pacing/index.html      800m Racing Guide
guides/styles.css                  Styles for the guide pages
guides/800m-pacing/pace-explorer.js Interactive lap split calculator
sitemap.xml                        Google-readable sitemap
robots.txt                         Crawl rules and sitemap location

Important:
- All navigation now uses real page links rather than the old #calculator/#about-faq fragments.
- The old fragments on the homepage redirect to the new pages to support saved links.
- This is a static HTML/CSS/JavaScript site: GitHub Pages hosts it without a separate server.
- After deployment, check all five pages and submit https://stridecalculator.com/sitemap.xml in Google Search Console.
- Don't delete unrelated files from your existing repository when uploading this package.
